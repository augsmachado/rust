fn main() {
	println!("Congrats! Your Rust script is running");
}
